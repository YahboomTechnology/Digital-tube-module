#include "GPIO.h"
//#include "OLED.h"
//#include "adc.h"
//#include  "ctrlsport.h"
/*������ */
void BEEP_Init()
{

	GPIO_InitTypeDef GPIO_InitStructure;
	
	RCC_APB2PeriphClockCmd(Beep_RCC, ENABLE);
	
	GPIO_InitStructure.GPIO_Pin =  GPIO_Pin_13;	
	
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	
	GPIO_Init(GPIOB, &GPIO_InitStructure);
	
	GPIO_ResetBits(GPIOB,GPIO_Pin_13);


	
}
void ZD_Init()
{
	GPIO_InitTypeDef GPIO_InitStructure;
	
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);
	
	GPIO_InitStructure.GPIO_Pin =  GPIO_Pin_4;	
	
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;
	
	GPIO_Init(GPIOA, &GPIO_InitStructure);


}

void KEY_Init()
{

	GPIO_InitTypeDef GPIO_InitStructure;
	
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);
	
	GPIO_InitStructure.GPIO_Pin =  GPIO_Pin_1;	
	
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	
	GPIO_Init(GPIOA, &GPIO_InitStructure);
	
//	GPIO_ResetBits(GPIOA,GPIO_Pin_1);

//	 GPIO_EXTILineConfig(GPIO_PortSourceGPIOA, GPIO_PinSource1);//ѡ��GPIO�ܽ������ⲿ�ж���·    

//	 EXTI_InitTypeDef	EXTI_InitStructure;
//	
//  EXTI_InitStructure.EXTI_Mode = EXTI_Mode_Interrupt; //�ж�����ģʽ
//	EXTI_InitStructure.EXTI_Line = EXTI_Line1; //�ⲿ�ж���
//	EXTI_InitStructure.EXTI_Trigger = EXTI_Trigger_Falling; //����������·�½���Ϊ�ж�����
//	EXTI_InitStructure.EXTI_LineCmd = ENABLE; //ʹ��
//	EXTI_Init(&EXTI_InitStructure);//��ʼ��


//	NVIC_InitTypeDef NVIC_InitStructure;
//  NVIC_InitStructure.NVIC_IRQChannel =EXTI1_IRQn; //�ⲿ�ж���3���ж�
//	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority =0;//��ռ���ȼ�
//	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 1; //��Ӧ���ȼ�
//	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE; 
//	NVIC_Init(&NVIC_InitStructure);

}
void LED_Init()
{

	GPIO_InitTypeDef GPIO_InitStructure;
	
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOC, ENABLE);
	
	GPIO_InitStructure.GPIO_Pin =  GPIO_Pin_13;	
	
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	
	GPIO_Init(GPIOC, &GPIO_InitStructure);
	
//	GPIO_ResetBits(GPIOC,GPIO_Pin_13);


	
}




//void sportmain(void)
//{
//			int len;
//			len=bsp_getUltrasonicDistance();
//			printf("%d\n",len);
//	   
////			if(fVoltage<1.95)
////			{
//////				GPIO_SetBits(GPIOB,GPIO_Pin_13);
////			}
////			
////			
////			if(len < 25)
////      { 
////				len = (u16)bsp_getUltrasonicDistance();
////				while(len < 25)
////					{    
//////						  GPIO_SetBits(GPIOB,GPIO_Pin_13);
////							Car_Stop();  
////							Car_Right(5000);
////							delay_ms(300);
////							len = (u16)bsp_getUltrasonicDistance();
////					}
////       }
////      else 
////	     {
////						 Car_Run(5500);   		
////	     }
//}


//void EXTI1_IRQHandler(void)//�ж���3���жϺ���
//{
//	if(EXTI_GetITStatus(EXTI_Line1)!=RESET)
//{
//	GPIO_SetBits(GPIOC,GPIO_Pin_13);
//	beer();
//	EXTI_ClearITPendingBit(EXTI_Line1);
//	}
//}
