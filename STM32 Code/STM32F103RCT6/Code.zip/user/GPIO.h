#ifndef _GPIO
#define _GPIO

#include "stm32f10x.h"


#define Beep_RCC		 RCC_APB2Periph_GPIOB


#define Motor_RCC		 RCC_APB2Periph_GPIOA
#define Motor_Port		 GPIOA
#define Left_MotoA_Pin 	 GPIO_Pin_0
#define Left_MotoB_Pin 	 GPIO_Pin_1

#define Right_MotoA_Pin	 GPIO_Pin_2
#define Right_MotoB_Pin  GPIO_Pin_3


void BEEP_Init();
void KEY_Init();
void LED_Init();
//void sportmain(void);



#endif