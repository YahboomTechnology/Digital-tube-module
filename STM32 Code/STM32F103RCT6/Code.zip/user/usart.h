#ifndef __USART_H
#define	__USART_H


#include "stm32f10x.h"
#include <stdio.h>



void USART_Config(void);
void DEBUG_USART_IRQHandler(void);
void Usart_SendByte( USART_TypeDef * pUSARTx, uint8_t ch);
void Usart_SendString( USART_TypeDef * pUSARTx, char *str);
int  fputc(int ch,FILE *f);
int fgetc(FILE *f);
void IpToInt(char* pBuffer,int len,int* pArr);
#endif /* __usart_H */
 