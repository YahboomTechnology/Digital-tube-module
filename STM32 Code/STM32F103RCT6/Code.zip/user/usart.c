#include "usart.h" 
#include "GPIO.h"
#include "stm32f10x.h"
#include "string.h"
enum{
  enSTOP = 0,
  enRUN,
  enBACK,
  enLEFT,
  enRIGHT,
	beerout,
	ultra,
	oledshowip,

}CarState;


	void USART_Config(void)
  {
		RCC_APB2PeriphClockCmd(RCC_APB2Periph_USART1,ENABLE);
		RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA,ENABLE);
		GPIO_InitTypeDef   gpio_li;
		USART_InitTypeDef  USART_LI;
		NVIC_InitTypeDef  nvic_li;
		
		gpio_li.GPIO_Pin=GPIO_Pin_9;
		gpio_li.GPIO_Mode=GPIO_Mode_AF_PP;
		gpio_li.GPIO_Speed=GPIO_Speed_50MHz;
		GPIO_Init(GPIOA,&gpio_li);
		
		gpio_li.GPIO_Pin=GPIO_Pin_10;
		gpio_li.GPIO_Mode=GPIO_Mode_IN_FLOATING;
		GPIO_Init(GPIOA,&gpio_li);
		
		
		USART_LI.USART_BaudRate=115200;
		USART_LI.USART_WordLength=USART_WordLength_8b;
		USART_LI.USART_StopBits=USART_StopBits_1;
		USART_LI.USART_Parity=USART_Parity_No;
		USART_LI.USART_HardwareFlowControl=USART_HardwareFlowControl_None;
		USART_LI.USART_Mode=USART_Mode_Tx|USART_Mode_Rx;
		USART_Init(USART1,&USART_LI);
				
		nvic_li.NVIC_IRQChannel=USART1_IRQn;
	  nvic_li.NVIC_IRQChannelPreemptionPriority=0;
	  nvic_li.NVIC_IRQChannelSubPriority=0;
	  nvic_li.NVIC_IRQChannelCmd=ENABLE;
	  NVIC_Init(&nvic_li);
				
	  USART_ITConfig(USART1,USART_IT_RXNE,ENABLE);
		USART_Cmd(USART1,ENABLE);
		 
				
  }
	
u16 i=0; 
u8 ch[5];
u8 a;
char *b;
int cAa[4] = {0};
void USART1_IRQHandler(void)                	//
	{
				u8 res;
	if(USART_GetITStatus(USART1, USART_IT_RXNE) != RESET)  //�����ж�(���յ������ݱ�����0x0d 0x0a��β)
		{
					;
			}

			 USART_ClearITPendingBit(USART1,USART_IT_RXNE);

	}
	
	void Usart_SendByte( USART_TypeDef * pUSARTx, uint8_t ch)
  {
      USART_SendData(USART1,ch);
		  while (USART_GetFlagStatus(USART1,USART_FLAG_TXE)==RESET);
   }

  void Usart_SendString( USART_TypeDef * pUSARTx, char *str)
  {
		  
    uint8_t a=0;
		do
		{
			Usart_SendByte(USART1,*(str+a));
			a++;
		}while(*(str+a)!='\0');
		
		while (USART_GetFlagStatus(USART1,USART_FLAG_TC)==RESET)
		{}
  }
int  fputc(int ch,FILE *f)
	
{
   USART_SendData(USART1,(uint8_t) ch);
	 while(USART_GetFlagStatus(USART1,USART_FLAG_TXE)==RESET);
	
	 return (ch);


}

int fgetc(FILE *f)
{
  while(USART_GetFlagStatus(USART1,USART_FLAG_RXNE)==RESET);
	return (int)USART_ReceiveData(USART1);

}

//ip��ַ
void IpToInt(char* pBuffer,int len,int* pArr)
{
		char* pCur = pBuffer;
		int i = 0;
		int k = 0;
		pArr[i] = atoi(pCur);

		while(k++ < len)
		{
		if(*pCur == '.')
		{
		pArr[++i] = atoi(pCur + 1);
		}
		pCur++;

		}
}


