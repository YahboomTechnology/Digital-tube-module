#include "stm32f10x.h"

#include "usart.h"
#include "tm1650.h"


void delay_ms(unsigned int ms)
{
	unsigned char k;
	while(ms--)
	{
	for(k = 0; k < 114; k++);
	}
}


 int main()
	 {
			IIC_Init();
			USART_Config();

		while(1)
		{
			TM1650_SetDisplay(3, 8, 1);
			TM1650_SetNumber(1, 7, 1);
			TM1650_SetNumber(2, 7, 0);
			TM1650_SetNumber(3, 8, 4);
			TM1650_SetNumber(4, 7, 3);
		}
		
	}


	
	