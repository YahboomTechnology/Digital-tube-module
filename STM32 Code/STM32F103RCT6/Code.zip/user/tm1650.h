#ifndef _TM1650_H
#define _TM1650_H



#include "stm32f10x.h"
#define IIC_SCL_CLK         RCC_APB2Periph_GPIOB        // GPIO�˿�ʱ��
#define IIC_SCL_PORT        GPIOB                       // GPIO�˿�
#define IIC_SCL_PIN         GPIO_Pin_6                  // GPIO����
// I2C_SDAʱ��
#define IIC_SDA_CLK         RCC_APB2Periph_GPIOB        // GPIO�˿�ʱ��
#define IIC_SDA_PORT        GPIOB                       // GPIO�˿�
#define IIC_SDA_PIN         GPIO_Pin_7                 // GPIO����

/*********************************************************************
 * MACROS
 */
#define IIC_SCL_0()         GPIO_ResetBits(IIC_SCL_PORT, IIC_SCL_PIN) 
#define IIC_SCL_1()         GPIO_SetBits(IIC_SCL_PORT, IIC_SCL_PIN)
#define IIC_SDA_0()         GPIO_ResetBits(IIC_SDA_PORT, IIC_SDA_PIN) 
#define IIC_SDA_1()         GPIO_SetBits(IIC_SDA_PORT, IIC_SDA_PIN) 
#define IIC_SDA_READ()      GPIO_ReadInputDataBit(IIC_SDA_PORT, IIC_SDA_PIN) 

/*********************************************************************
 * API FUNCTIONS
 */
void IIC_Init(void);			 
void IIC_Start(void);
void IIC_Stop(void);
void IIC_SendByte(uint8_t ucByte);
uint8_t IIC_ReadByte(void);
uint8_t IIC_WaitAck(void);
void IIC_Ack(void);
void IIC_NAck(void);
uint8_t IIC_CheckDevice(uint8_t address);


void TM1650_Write(u8 addr, u8 data);
void TM1650_SetDisplay(u8 brightness, u8 mode, u8 state);
void TM1650_SetNumber(u8 index, u8 mode, u8 num);



#endif